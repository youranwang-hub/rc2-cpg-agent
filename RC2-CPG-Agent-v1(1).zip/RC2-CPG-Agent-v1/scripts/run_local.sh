#!/usr/bin/env bash
set -eu
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/src"
export PYTHONUTF8=1
cd "$ROOT"
python3 -m rc2_cpg_agent local --output-dir "$ROOT/artifacts/local-run" --verify-expected
