$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = Join-Path $Root "src"
$env:PYTHONUTF8 = "1"
Set-Location $Root
python -m unittest discover -s tests -v
exit $LASTEXITCODE
