param(
    [Parameter(Mandatory = $true)]
    [string]$Joern,
    [Parameter(Mandatory = $true)]
    [string]$Cpg,
    [string]$SourceRoot = "",
    [string]$OutputDir = "",
    [string]$JoernVersion = "",
    [int]$Timeout = 180,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = Join-Path $Root "src"
$env:PYTHONUTF8 = "1"
Set-Location $Root

if ([string]::IsNullOrWhiteSpace($SourceRoot)) {
    $SourceRoot = Join-Path $Root "reference\uhttpd-case\uhttpd"
}
if ([string]::IsNullOrWhiteSpace($OutputDir)) {
    $OutputDir = Join-Path $Root "artifacts\lab-run"
}

$Arguments = @(
    "-m", "rc2_cpg_agent", "lab",
    "--joern", $Joern,
    "--cpg", $Cpg,
    "--source-root", $SourceRoot,
    "--output-dir", $OutputDir,
    "--timeout", $Timeout,
    "--verify-expected"
)
if (-not [string]::IsNullOrWhiteSpace($JoernVersion)) {
    $Arguments += @("--joern-version", $JoernVersion)
}
if ($DryRun) {
    $Arguments += "--dry-run"
}

python @Arguments
exit $LASTEXITCODE
