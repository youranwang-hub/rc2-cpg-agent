$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = Join-Path $Root "src"
$env:PYTHONUTF8 = "1"
Set-Location $Root
python -m rc2_cpg_agent local --output-dir (Join-Path $Root "artifacts\local-run") --verify-expected
exit $LASTEXITCODE
