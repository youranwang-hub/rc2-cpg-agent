#!/usr/bin/env bash
set -eu
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/src"
export PYTHONUTF8=1
cd "$ROOT"
python3 -m unittest discover -s tests -v
