#!/usr/bin/env bash
set -eu
if [ "$#" -lt 2 ]; then
  echo "用法: bash scripts/preflight_lab.sh <joern路径> <cpg路径> [源码目录]" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JOERN="$1"
CPG="$2"
SOURCE_ROOT="${3:-$ROOT/reference/uhttpd-case/uhttpd}"
export PYTHONPATH="$ROOT/src"
export PYTHONUTF8=1
cd "$ROOT"
python3 -m rc2_cpg_agent preflight \
  --joern "$JOERN" \
  --cpg "$CPG" \
  --source-root "$SOURCE_ROOT" \
  --report "$ROOT/artifacts/preflight/preflight-report.json"
