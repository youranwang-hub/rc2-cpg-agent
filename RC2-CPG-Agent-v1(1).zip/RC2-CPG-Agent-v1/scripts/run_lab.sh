#!/usr/bin/env bash
set -eu
if [ "$#" -lt 2 ]; then
  echo "用法: bash scripts/run_lab.sh <joern路径> <cpg路径> [源码目录|dry-run] [dry-run]" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JOERN="$1"
CPG="$2"
SOURCE_ROOT="$ROOT/reference/uhttpd-case/uhttpd"
EXTRA=""
if [ "${3:-}" = "dry-run" ]; then
  EXTRA="dry-run"
elif [ -n "${3:-}" ]; then
  SOURCE_ROOT="$3"
  EXTRA="${4:-}"
fi
export PYTHONPATH="$ROOT/src"
export PYTHONUTF8=1
cd "$ROOT"

ARGS=(
  -m rc2_cpg_agent lab
  --joern "$JOERN"
  --cpg "$CPG"
  --source-root "$SOURCE_ROOT"
  --output-dir "$ROOT/artifacts/lab-run"
  --timeout 180
  --verify-expected
)
if [ "$EXTRA" = "dry-run" ]; then
  ARGS+=(--dry-run)
fi
python3 "${ARGS[@]}"
