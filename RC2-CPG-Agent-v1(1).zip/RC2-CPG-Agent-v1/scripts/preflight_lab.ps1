param(
    [Parameter(Mandatory = $true)]
    [string]$Joern,
    [Parameter(Mandatory = $true)]
    [string]$Cpg,
    [string]$SourceRoot = "",
    [string]$Report = ""
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = Join-Path $Root "src"
$env:PYTHONUTF8 = "1"
Set-Location $Root

if ([string]::IsNullOrWhiteSpace($SourceRoot)) {
    $SourceRoot = Join-Path $Root "reference\uhttpd-case\uhttpd"
}
if ([string]::IsNullOrWhiteSpace($Report)) {
    $Report = Join-Path $Root "artifacts\preflight\preflight-report.json"
}

python -m rc2_cpg_agent preflight --joern $Joern --cpg $Cpg --source-root $SourceRoot --report $Report
exit $LASTEXITCODE
