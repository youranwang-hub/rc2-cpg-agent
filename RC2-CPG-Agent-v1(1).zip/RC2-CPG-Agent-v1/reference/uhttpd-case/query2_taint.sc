importCpg("/Users/uu/Projects/detect/experiments/uhttpd.cpg.bin")

// ====================================================
// 关键测试1：跨函数污点追踪
// strtoul (client_parse_header) → content_length → ustream_consume (client_poll_post_data)
// ====================================================
println("=== TAINT TEST 1: strtoul → ustream_consume (跨函数) ===")
val flows = cpg.call.name("ustream_consume").argument(2)
  .reachableByFlows(cpg.call.name("strtoul")).l

if (flows.isEmpty) {
  println("  [FAIL] reachableByFlows 返回空 - 跨函数污点追踪失败")
} else {
  println(s"  [PASS] 找到 ${flows.length} 条污点路径")
  flows.take(2).foreach { flow =>
    println("  --- 路径 ---")
    flow.elements.foreach { e =>
      println(s"    ${e.location.filename}:${e.location.lineNumber.getOrElse(-1)}  | ${e.statement.code.take(80)}")
    }
  }
}

// ====================================================
// 关键测试2：函数内部追踪（验证 client_poll_post_data 内 chunked path）
// ====================================================
println("\n=== TAINT TEST 2: 函数内 strtoul → ustream_consume ===")
val flowsIntra = cpg.method.name("client_poll_post_data").ast.isCall.name("ustream_consume").argument(2)
  .reachableByFlows(
    cpg.method.name("client_poll_post_data").ast.isCall.name("strtoul")
  ).l

if (flowsIntra.isEmpty) {
  println("  [FAIL] 函数内追踪失败")
} else {
  println(s"  [PASS] 函数内找到 ${flowsIntra.length} 条路径")
  flowsIntra.head.elements.foreach { e =>
    println(s"    :${e.location.lineNumber.getOrElse(-1)}  | ${e.statement.code.take(80)}")
  }
}

// ====================================================
// 关键测试3：content_length 是否携带类型信息（int vs unsigned long）
// ====================================================
println("\n=== TAINT TEST 3: content_length 赋值的类型检查 ===")
cpg.assignment
  .where(_.target.code(".*content_length.*"))
  .where(_.source.isCall.name("strtoul"))
  .map { a =>
    val targetType = a.target.evalType.headOption.getOrElse("unknown")
    val sourceType = a.source.evalType.headOption.getOrElse("unknown")
    s"  :${a.lineNumber.getOrElse(-1)}  target_type=${targetType}  source_type=${sourceType}  |  ${a.code.take(60)}"
  }.l.foreach(println)
