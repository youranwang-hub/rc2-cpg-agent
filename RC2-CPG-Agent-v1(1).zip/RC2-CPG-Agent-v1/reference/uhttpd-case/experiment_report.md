# Joern CPG 污点追踪验证实验报告

**日期**：2026-06-08  
**目的**：验证 Φ 映射所需的 CPG 事实能否被查询，并评估从数据流到协议约束的映射边界

---

## 一、实验背景

论文设计的 Φ 映射从漏洞节点沿 CPG 数据依赖追踪至协议输入，再将已验证的代码事实转换为协议字段约束（SH）。

本实验通过对真实固件组件运行 Joern CPG 查询，评估该映射所需事实的可观测性。

---

## 二、实验设置

| 项目 | 内容 |
|------|------|
| 分析目标 | OpenWRT uhttpd（HTTP 管理服务器）C 源码 |
| 目标版本 | commit `778ccbb`（CVE-2019-19945 修复前的漏洞版本） |
| 工具 | Joern 4.0.550，c2cpg 前端 |
| 漏洞 | CVE-2019-19945：HTTP POST 长度解析中的整数符号/转换错误可使 `ustream_consume` 获得异常长度；官方影响为越界访问与崩溃，本实验仅验证其中的静态节点、局部数据流和数值转换机制 |

---

## 三、实验内容与结果

### 步骤 1：CPG 构建

对 uhttpd 全部 .c 源文件运行 `joern-parse`，生成 `uhttpd.cpg.bin`。

**结果**：成功生成 CPG，后续固定查询可执行。

---

### 步骤 2：漏洞节点定位（T1 证据查询）

**查询**：找到 `strtoul` 返回值赋给 `content_length` 的所有代码点。

**结果**：
```
client.c:394  client_parse_header     r->content_length = strtoul(val, &err, 10)
client.c:489  client_poll_post_data   r->content_length = strtoul(buf + offset, &sep, 16)
```

两处赋值均命中，定位精度到文件名 + 行号 + 函数名。

---

### 步骤 3：前置条件验证（缺失检查确认）

**查询**：`client_parse_header` 中是否存在对 `content_length` 的 INT_MAX 上界检查。

**结果**：现有查询返回的比较节点为空，但源码中明确存在 `content_length < 0` 守卫，说明当前查询模式未完整覆盖已有检查。因此本轮不将空结果记为“缺少上界检查”的 T1 证据，该前置条件保持 `unknown`，待修正查询模板后重新裁定。

---

### 步骤 4：反向污点追踪（Φ 核心机制）

**查询**：从 `ustream_consume` 的第 2 个参数出发，`reachableByFlows` 追踪到 `strtoul`。

**结果**：
```
strtoul(buf + offset, &sep, 16)          [client.c:489]
  → r->content_length = strtoul(...)     [489]
  → min(r->content_length, len)          [464]
  → cur_len = min(...)                   [464]
  → ustream_consume(cl->us, cur_len)     [473]
```

路径长度 9 步，在 `client_poll_post_data` 函数内穿越 `r->content_length` 字段赋值和 `min()` 宏展开，最终到达 sink。该结果验证了同一函数内的字段数据流；`client_parse_header:394` 到 `client_poll_post_data:473` 的跨函数字段路径未被找到。两条路径分别记录，不合并为一条已验证路径。

---

### 步骤 5：协议语义识别（Φ 终止条件）

**查询**：CPG 中与 Transfer-Encoding 相关的字符串字面量。

**结果**：
```
client.c:52   "Transfer-Encoding: chunked\r\n"
client.c:400  "chunked"
client.c:399  "transfer-encoding"
```

Joern 可从 CPG 字符串节点定位协议关键词。这些节点可作为 Φ 映射的候选终止边界，仍需与对应数据流路径建立关联。

---

### 步骤 6：Φ 约束集合输出（SH）

基于以上 CPG 事实人工整理的 SH 候选：

```
HTTP 协议约束（SH）：
  方法:         POST
  头部:         Transfer-Encoding: chunked
  载荷格式:     chunked 编码体，chunk size 行为大十六进制值
  字段约束:     chunk size 超出 int 范围，且截断后低 32 位为非负数
  触发目标:     client_poll_post_data() → ustream_consume(cl->us, cur_len) 执行错误长度
  验证方式:     uhttpd 崩溃 / 返回非预期状态码
```

当前脚本中的 SH 为固定文本输出，尚未实现从查询结果到 SH 的自动转换。该候选需经完整 uhttpd 环境验证后才能作为 RC3 输入。

---

## 四、实验结论

| 验证项 | 结论 |
|--------|------|
| CPG 可在真实固件 C 代码上成功构建 | ✅ |
| Joern 可定位到漏洞赋值节点（文件/行号/函数） | ✅ |
| `reachableByFlows` 可在同一函数内穿越 struct 字段和宏展开 | ✅ |
| 从 CPG 字符串字面量可识别协议层关键词 | ✅ |
| 生成 SH 所需的部分 CPG 事实可查询 | ✅ |
| 从查询结果自动生成 SH | ⏳ 待实现 |
| 缺少上界检查的 T1 自动裁定 | ⚠️ 当前查询漏掉已有 `< 0` 守卫，待修正 |
| 跨函数 struct 字段的 interprocedural 追踪 | ⚠️ 有限制（见下） |
| 类型系统（strtoul 返回 unsigned long 赋给 int） | ⚠️ Joern 报告 ANY，需借助函数名规则弥补 |

---

## 五、已发现的两处诚实限制

**限制 1：跨函数 struct 字段污点追踪**

成功的追踪路径（:489 → :473）在同一函数 `client_poll_post_data` 内完成。另一条路径（`client_parse_header` :394 → `client_poll_post_data` :473，通过 struct 字段跨函数传递）未被 Joern 找到。跨函数的 struct 别名分析超出了当前静态分析的能力边界。

**影响**：Φ 的适用范围应表述为"漏洞节点与协议输入解析在 Joern interprocedural 分析可达的范围内"，不能声明对所有跨函数路径均有效。

**限制 2：C 类型信息解析**

Joern 对 C 代码的类型推断报告为 `ANY`，无法直接通过类型系统查询"`strtoul` 赋给 `int`"这种类型不匹配模式。实践中需通过函数名（`strtoul` 已知返回 `unsigned long`）与目标变量声明（`int content_length`）两步分别查询后手工关联。

---

## 六、对论文的意义

1. **基础查询可行**：Joern 可定位漏洞赋值、同函数数据流和协议字符串。跨函数字段追踪及自动 SH 转换尚待实现。

2. **CVE 案例替换**：CVE-2019-19945 可用于整数转换和边界检查案例，当前已完成节点定位和局部数据流验证。

3. **复现材料已保存**：uhttpd 源码、CPG 和 Joern 查询脚本已保存，需在相同 commit 与 Joern 版本下重放确认。

---

---

## 补充：优先级 2 实验——netifd blobmsg CPG 表示验证

**日期**：2026-06-07  
**目标**：确认 ubus/netifd 两步映射所需的 `blobmsg_get_string`、policy 字段名和数据流事实能否被 Joern CPG 捕获。

### 实验设置

| 项目 | 内容 |
|------|------|
| 分析目标 | netifd（OpenWRT 网络接口守护进程）C 源码 |
| 工具 | Joern 4.0.550，c2cpg 前端 |
| CPG 文件 | `netifd.cpg.bin` |

### 结果

**Q1：blobmsg_get_string 调用在 CPG 中可见？**  
✅ 找到 42 处调用，覆盖 bridge.c / device.c / config.c / interface.c / bonding.c / ubus.c 等所有核心文件，精度达到文件名 + 行号 + 所在函数。

**Q2：blobmsg_policy 字段名字符串在全局作用域可见？**  
✅ bridge.c:50-68 中 `"ports"`、`"stp"`、`"forward_delay"` 等全部可见；bonding.c:88-106 中 14 个字段名同样可见。这些字段名就是 Φ 对应的协议层输入字段约束。

**Q3：blobmsg_get_string → memcpy/strcpy 污点追踪有效？**  
✅ 找到 32 条路径，关键路径：
```
config.c:730  blobmsg_get_string(cur) → device.c:726  memcpy(s->macaddr, ea, 6)
config.c:517  blobmsg_get_string(attr) → config.c:255  strcpy(dev_name_buf, dev_name)
```

### netifd Φ 终止条件的设计要点

netifd 的 Φ 终止条件与 uhttpd 存在结构差异：
- uhttpd：字段名（`"content-length"`、`"transfer-encoding"`）出现在字符串比较调用中，直接在数据流路径上
- netifd：`blobmsg_get_string(cur)` 返回字段值，字段名存储在全局 `blobmsg_policy` 数组中，通过 `cur` 的数组下标与值绑定

因此 netifd 场景的 Φ 终止条件识别需要两步：
1. 数据流路径上定位 `blobmsg_get_string` 调用（Q1/Q3 已验证）
2. 在全局作用域查找同文件 `blobmsg_policy` 数组，取对应下标处的字段名（Q2 已验证可见）

### 结论

| 验证项 | 结论 |
|--------|------|
| blobmsg_get_string 调用在 CPG 中可定位 | ✅ |
| policy 字段名字符串作为全局字面量可见 | ✅ |
| reachableByFlows 从 blobmsg_get_string 到内存操作有效 | ✅ |
| 两步映射所需的基础事实可观察 | ✅ |
| policy 下标关联与自动终止判定 | ⏳ 待实现 |

**netifd 路线具备继续实现两步映射的基础条件。**

---

---

## 补充：优先级 3 实验——数值转换机制的最小化验证

**日期**：2026-06-08  
**目标**：验证 `strtoul` 返回值转换为 `int` 时的数值截断及边界检查差异。

### 方法说明

uhttpd 依赖 libubox，当前未在 macOS 运行完整服务。本实验从 uhttpd/client.c 提取等价的数值转换代码，在当前 64 位 Clang 环境中比较旧守卫与修复后边界检查。该程序不包含完整 uhttpd、`ustream_consume` 或网络交互。

复现器路径：`experiments/cve_2019_19945_poc.c`

### 最小化测试输入

```
POST /path HTTP/1.1\r\n
Content-Length: 4294967297\r\n     ← 2^32 + 1，低 32 位 = 1
\r\n
x                                  ← 仅 1 字节 body
```

### 漏洞触发机制

在 64 位系统上，`strtoul("4294967297")` 返回 `4294967297UL`（`unsigned long`，64 位）。赋给 `int content_length` 时发生截断：高 32 位丢弃，低 32 位 `0x00000001 = 1`。

旧守卫 `r->content_length < 0` 对 1 不成立，因此最小化旧逻辑接受该值并将 `content_length` 记为 1。

输入文本声明的 Content-Length 为 4294967297。

### 实验结果

编译命令：
```bash
clang -fsanitize=undefined,implicit-conversion -o poc cve_2019_19945_poc.c
```

**Clang 隐式转换检测器在等价转换代码中捕获的 runtime error：**
```
cve_2019_19945_poc.c:37: runtime error: implicit conversion from type 'unsigned long'
of value 2147483648 (64-bit, unsigned) to type 'int' changed the value to -2147483648
(32-bit, signed)
```

**新旧检查结果不同的案例：**

| Content-Length 值 | strtoul 返回值 | 存入 int | 守卫结果 | 修复后 |
|---|---|---|---|---|
| 4294967296 (2^32) | 4294967296 | 0 | 通过（= 0） | 拒绝 |
| **4294967297 (2^32+1)** | **4294967297** | **1** | **通过** | **拒绝** |
| 4295000064 | 4295000064 | 32768 | 通过 | 拒绝 |
| 9999999999 | 9999999999 | 1410065407 | 通过 | 拒绝 |

**正常值（两版本行为一致）：**
- Content-Length: 100 → 通过（正确）
- Content-Length: 2147483648 → 拒绝（低 32 位负数，守卫命中）
- Content-Length: -1 → 拒绝（strtoul wraps to ULONG_MAX，存为 -1，守卫命中）

### 验证边界

当前结果只证明特定输入在当前平台上发生数值截断，且新旧检查的接受结果不同。实验没有向完整 uhttpd 发包，未观察到 `ustream_consume` 越界、进程崩溃或 HTTP 请求走私，因此不对这些影响作动态验证结论。

### 与静态分析结果的对应关系

| 静态分析（Joern Φ 映射） | 动态验证（PoC + UBSan） |
|---|---|
| client.c:394 存在 strtoul→int 赋值 | UBSan 在等价代码行触发 runtime error |
| 限定查询范围内未观察到 INT_MAX 上界检查 | 当低 32 位截断为非负数时，旧检查接受超范围输入 |
| Content-Length = 2^32 + N（低位为小正数） | 输入 4294967297 时旧检查接受、新检查拒绝 |
| 修复路径：strtol + errno + INT_MAX 检查 | 修复后逻辑拒绝当前超范围测试集 |

### 结论

| 验证项 | 结论 |
|--------|------|
| 数值转换层的截断行为可复现 | ✅ |
| Clang 隐式转换检测器捕获 strtoul→int 截断 | ✅ |
| 旧守卫可接受低 32 位截断为非负数的超范围输入 | ✅ |
| 修复后检查在当前测试集上拒绝超范围值 | ✅ |
| 完整 uhttpd 越界访问或崩溃验证 | ⏳ 未完成 |

---

## 七、下一步

- [ ] 将 CVE-2021-22161 替换为 CVE-2019-19945，更新论文 Section 3.5 的 Φ 执行示例
- [ ] 在论文中说明 netifd 场景 Φ 终止条件的两步设计（数据流 + policy 全局查找）
- [ ] 在 Section 3.5 的 Φ 适用范围说明中补充跨函数限制
- [x] 完成数值转换机制的最小化验证
- [ ] 在完整 uhttpd 环境中验证官方 CVE 触发路径与影响
- [ ] 实现从 verified_preconditions 到 SH 的确定性自动转换
