importCpg("/Users/uu/Projects/detect/experiments/uhttpd.cpg.bin")

// 查询1：找到 strtoul 调用
println("=== Q1: strtoul calls ===")
cpg.call.name("strtoul").map(c =>
  s"  ${c.file.name.headOption.getOrElse("?")}:${c.lineNumber.getOrElse(-1)}  in ${c.method.name}  |  ${c.code}"
).l.foreach(println)

// 查询2：找到 content_length 赋值点
println("\n=== Q2: content_length assignments ===")
cpg.assignment
  .where(_.target.code(".*content_length.*"))
  .map(a => s"  ${a.file.name.headOption.getOrElse("?")}:${a.lineNumber.getOrElse(-1)}  |  ${a.code}")
  .l.foreach(println)

// 查询3：找到 ustream_consume 调用
println("\n=== Q3: ustream_consume calls ===")
cpg.call.name("ustream_consume").map(c =>
  s"  ${c.file.name.headOption.getOrElse("?")}:${c.lineNumber.getOrElse(-1)}  in ${c.method.name}  |  args: ${c.argument.code.l.mkString(", ")}"
).l.foreach(println)
