# RC2 uhttpd CPG 分析实验包

本实验包在原有 RC2 Agent Demo 和学姐提供的 uhttpd 案例基础上完成，目标是让
“冻结结果回放”和“真实 Joern 查询”使用同一套状态机、证据格式和验收标准。

当前本地回放结果：

- 案例：CVE-2019-19945（OpenWrt uhttpd）
- 漏洞假设状态：`likely`
- 已确认：3/5 个前置条件
- 尚未闭合：跨函数字段流、`INT_MAX` 上界守卫
- 与学姐实验报告中的源码锚点一致

## 本机是否要安装 Joern

不需要。`local` 模式只运行 Python 标准库，不需要第三方包，也不会连接网络。

要在真实 CPG 上重跑查询时，再到实验室电脑使用 Joern。推荐只在实验室统一分析机上
安装一次，不要把 Joern 装到每个人的电脑。

## 本机快速开始

Windows PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_local.ps1
```

Linux/macOS：

```bash
bash scripts/run_local.sh
```

运行后会生成一个带时间戳的目录：

```text
artifacts/local-run/run-时间/
├── manifest.json
├── anchor-check.json
├── final-state.json
├── iterations.jsonl
└── raw/
```

## 到实验室后

先阅读 [使用说明.md](使用说明.md)，再按 [实验室操作清单.md](实验室操作清单.md)
逐步执行。最重要的顺序是：

1. `preflight`：检查 Joern、CPG 和源码路径。
2. `--dry-run`：只生成查询脚本，不执行。
3. `lab`：真正运行五条查询。
4. 检查 `anchor-check.json` 是否与实验报告一致。

## 重要限制

- 当前本地运行的节点 ID 是冻结占位值，不是真实 CPG ID。
- `local` 模式证明解析器和状态机可重复运行，不证明查询已在 Joern 中编译成功。
- 空查询结果不能证明条件为假。没有封闭世界保证时，状态保持 `unknown`。
- 本项目尚未完成完整 uhttpd 动态漏洞触发，也没有连接物理交换机。
- 真实运行前，候选 CPGQL 仍需在 Joern 4.0.550 上验证。

详细的定义、命令和排错方法见 [使用说明.md](使用说明.md)。
