import contextlib
import io
import json
import shutil
import unittest
import uuid
from pathlib import Path
from types import SimpleNamespace

from rc2_cpg_agent.cli import command_lab, command_local


class CliTest(unittest.TestCase):
    def setUp(self):
        self.base = Path.cwd() / ".test-tmp" / uuid.uuid4().hex

    def tearDown(self):
        shutil.rmtree(self.base, ignore_errors=True)

    def test_local_command_writes_manifest_and_anchor_report(self):
        args = SimpleNamespace(
            output_dir=self.base,
            max_iterations=10,
            verify_expected=True,
            fail_on_anchor_mismatch=False,
        )
        with contextlib.redirect_stdout(io.StringIO()):
            code = command_local(args)
        self.assertEqual(code, 0)
        run_dir = next(self.base.glob("run-*"))
        self.assertTrue((run_dir / "final-state.json").is_file())
        self.assertTrue((run_dir / "anchor-check.json").is_file())
        manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["backend"], "fixture")
        self.assertEqual(manifest["query_plan_version"], "uhttpd-real-run-v1")
        self.assertIn("limitations", manifest)

    def test_lab_dry_run_generates_five_scripts_without_execution(self):
        dummy_joern = self.base / "joern"
        dummy_joern.parent.mkdir(parents=True, exist_ok=True)
        dummy_joern.write_text("not executed in dry-run", encoding="utf-8")
        cpg = Path.cwd() / "reference" / "uhttpd-case" / "uhttpd.cpg.bin"
        args = SimpleNamespace(
            joern=str(dummy_joern),
            cpg=cpg,
            source_root=None,
            output_dir=self.base / "lab",
            timeout=10,
            max_iterations=10,
            joern_version="4.0.550",
            dry_run=True,
            verify_expected=True,
            fail_on_anchor_mismatch=False,
        )
        with contextlib.redirect_stdout(io.StringIO()):
            code = command_lab(args)
        self.assertEqual(code, 0)
        run_dir = next((self.base / "lab").glob("run-*"))
        scripts = sorted((run_dir / "scripts").glob("q*.sc"))
        self.assertEqual([path.name for path in scripts], [f"q{i}.sc" for i in range(1, 6)])
        self.assertTrue((run_dir / "dry-run.json").is_file())


if __name__ == "__main__":
    unittest.main()
