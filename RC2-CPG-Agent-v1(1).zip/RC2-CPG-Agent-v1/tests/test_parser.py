import json
import unittest

from rc2_cpg_agent.evidence import extract_json_records, extract_t1
from rc2_cpg_agent.models import ExecutionStatus, QueryResult, QuerySpec, Verdict


class ParserTest(unittest.TestCase):
    def test_parses_marked_pretty_json_array_with_logs(self):
        stdout = """
INFO: loading CPG
__RC2_JSON_BEGIN__
[
  {"marker": "INPUT", "id": 1, "file": "client.c", "line": 394}
]
__RC2_JSON_END__
INFO: done
"""
        records = extract_json_records(stdout)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["id"], 1)

    def test_parses_jsonl_fixture(self):
        stdout = '{"marker":"A","id":1}\n{"marker":"B","id":2}\n'
        records = extract_json_records(stdout)
        self.assertEqual([item["marker"] for item in records], ["A", "B"])

    def test_duplicate_node_ids_are_deduplicated_in_one_flow(self):
        spec = QuerySpec("qx", "cx", "purpose", "cpg.call", "DATAFLOW")
        payload = json.dumps(
            {
                "marker": "DATAFLOW",
                "path": [
                    {"id": 1, "file": "a.c", "line": 10, "code": "a", "function": "f"},
                    {"id": 1, "file": "a.c", "line": 10, "code": "a", "function": "f"},
                    {"id": 2, "file": "a.c", "line": 20, "code": "b", "function": "f"},
                ],
            }
        )
        result = QueryResult("qx", ExecutionStatus.SUCCESS, payload, "", 0, 1, backend="joern")
        verdict, evidence = extract_t1(spec, result)
        self.assertIs(verdict, Verdict.VERIFIED)
        self.assertEqual(evidence[0].cpg_node_ids, (1, 2))

    def test_empty_or_malformed_output_stays_unknown(self):
        spec = QuerySpec("qx", "cx", "purpose", "cpg.call", "X")
        for stdout in ("", "not json", "[]"):
            result = QueryResult("qx", ExecutionStatus.SUCCESS, stdout, "", 0, 1)
            verdict, evidence = extract_t1(spec, result)
            self.assertIs(verdict, Verdict.UNKNOWN)
            self.assertEqual(evidence, [])


if __name__ == "__main__":
    unittest.main()
