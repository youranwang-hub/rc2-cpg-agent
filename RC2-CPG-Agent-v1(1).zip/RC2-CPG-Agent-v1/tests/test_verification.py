import shutil
import unittest
import uuid
from pathlib import Path

from rc2_cpg_agent.executors import FixtureExecutor
from rc2_cpg_agent.runner import AnalysisRunner
from rc2_cpg_agent.verification import verify_against_expected


class VerificationTest(unittest.TestCase):
    def setUp(self):
        self.output = Path.cwd() / ".test-tmp" / uuid.uuid4().hex
        self.output.mkdir(parents=True)

    def tearDown(self):
        shutil.rmtree(self.output, ignore_errors=True)

    def test_fixture_matches_report_anchors(self):
        import rc2_cpg_agent.runner as runner

        fixture_dir = Path(runner.__file__).parent / "fixtures" / "uhttpd"
        state = AnalysisRunner(FixtureExecutor(fixture_dir), self.output).run()
        report = verify_against_expected(
            state,
            Path.cwd() / "expected_anchors.json",
            self.output / "anchor-check.json",
        )
        self.assertTrue(report["passed"], report)
        self.assertTrue(any(item["check"] == "empty_result" for item in report["checks"]))


if __name__ == "__main__":
    unittest.main()
