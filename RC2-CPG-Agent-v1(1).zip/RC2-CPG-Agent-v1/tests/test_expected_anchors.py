import json
import unittest
from pathlib import Path


class ExpectedAnchorTest(unittest.TestCase):
    def test_report_anchors_exist_in_packaged_source(self):
        root = Path.cwd()
        expected = json.loads((root / "expected_anchors.json").read_text(encoding="utf-8"))
        source_lines = (root / "reference" / "uhttpd-case" / "uhttpd" / "client.c").read_text(
            encoding="utf-8"
        ).splitlines()

        q1 = expected["queries"]["q1"]
        self.assertIn(q1["code_contains"], source_lines[393])

        q2 = expected["queries"]["q2"]
        self.assertIn(q2["code_contains"], source_lines[488])
        self.assertIn("min(r->content_length, len)", source_lines[463])
        self.assertIn("ustream_consume(cl->us, cur_len)", source_lines[472])

        report = (root / "reference" / "uhttpd-case" / "experiment_report.md").read_text(
            encoding="utf-8"
        )
        self.assertIn("778ccbb", report)
        self.assertTrue(expected["source_commit"].startswith("778ccbb"))


if __name__ == "__main__":
    unittest.main()
