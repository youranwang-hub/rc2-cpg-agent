import unittest
from pathlib import Path

from rc2_cpg_agent.cases import UHTTPD_QUERY_PLAN
from rc2_cpg_agent.executors import render_joern_script
from rc2_cpg_agent.models import QuerySpec, Verdict


class ScriptGenerationTest(unittest.TestCase):
    def test_script_contains_one_json_serializer_and_markers(self):
        cpg = Path("D:/中文 路径/uhttpd.cpg.bin")
        script = render_joern_script(UHTTPD_QUERY_PLAN[0], cpg)
        self.assertEqual(script.count(".toJsonPretty"), 1)
        self.assertIn("__RC2_JSON_BEGIN__", script)
        self.assertIn("__RC2_JSON_END__", script)
        self.assertIn("D:/中文 路径/uhttpd.cpg.bin", script)
        self.assertNotIn("/Users/uu", script)

    def test_existing_serializer_is_not_doubled(self):
        spec = UHTTPD_QUERY_PLAN[0]
        spec_with_suffix = QuerySpec(
            spec.query_id,
            spec.condition_id,
            spec.purpose,
            spec.cpgql + ".toJsonPretty",
            spec.positive_marker,
        )
        script = render_joern_script(spec_with_suffix, Path("test.cpg.bin"))
        self.assertEqual(script.count(".toJsonPretty"), 1)

    def test_upper_bound_guard_has_refuting_polarity(self):
        self.assertIs(UHTTPD_QUERY_PLAN[-1].marker_verdict, Verdict.REFUTED)


if __name__ == "__main__":
    unittest.main()
