import unittest

from rc2_cpg_agent.cases import build_uhttpd_hypothesis
from rc2_cpg_agent.models import AnalysisState, HypothesisStatus, Verdict
from rc2_cpg_agent.state_machine import apply_verdict, validate_state


class StateMachineTest(unittest.TestCase):
    def setUp(self):
        self.state = AnalysisState("case", build_uhttpd_hypothesis(), 10)

    def test_verified_and_refuted_conditions_leave_pending(self):
        apply_verdict(self.state, "attacker_ctl_length", Verdict.VERIFIED)
        apply_verdict(self.state, "upper_bound_guard", Verdict.REFUTED)
        self.assertIn("attacker_ctl_length", self.state.hypothesis.verified_preconditions)
        self.assertIn("upper_bound_guard", self.state.hypothesis.refuted_preconditions)
        self.assertNotIn("upper_bound_guard", self.state.hypothesis.verification_needed)
        self.assertIs(self.state.hypothesis.status, HypothesisStatus.REFUTED)
        self.assertAlmostEqual(self.state.hypothesis.decision_progress, 0.4)
        validate_state(self.state)

    def test_duplicate_decision_is_rejected(self):
        apply_verdict(self.state, "chunk_to_int", Verdict.VERIFIED)
        with self.assertRaises(ValueError):
            apply_verdict(self.state, "chunk_to_int", Verdict.VERIFIED)

    def test_conflicting_state_is_rejected(self):
        self.state.hypothesis.verified_preconditions.append("attacker_ctl_length")
        self.state.hypothesis.refuted_preconditions.append("attacker_ctl_length")
        with self.assertRaises(ValueError):
            validate_state(self.state)


if __name__ == "__main__":
    unittest.main()
