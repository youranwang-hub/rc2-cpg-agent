import unittest

from rc2_cpg_agent.cases import UHTTPD_QUERY_PLAN, build_uhttpd_hypothesis
from rc2_cpg_agent.evidence import extract_t1
from rc2_cpg_agent.models import (
    AnalysisState,
    ExecutionStatus,
    QueryResult,
    Verdict,
)
from rc2_cpg_agent.repair import RepairCandidate, store_t3_candidates


class SafetyTest(unittest.TestCase):
    def test_execution_success_is_not_automatically_verified(self):
        result = QueryResult("q1", ExecutionStatus.SUCCESS, "", "", 0, 1)
        verdict, evidence = extract_t1(UHTTPD_QUERY_PLAN[0], result)
        self.assertIs(verdict, Verdict.UNKNOWN)
        self.assertEqual(evidence, [])

    def test_t3_candidate_cannot_be_trusted_fact(self):
        state = AnalysisState("case", build_uhttpd_hypothesis(), 5)
        candidate = RepairCandidate(
            "r1",
            "variable_name",
            "content_length",
            "decompiler guess",
            "graph-repair",
        )
        store_t3_candidates(state, [candidate])
        self.assertFalse(state.repair_candidates[0].validated)
        self.assertEqual(state.hypothesis.verified_preconditions, [])

    def test_upper_bound_guard_query_refutes_missing_guard_condition(self):
        spec = UHTTPD_QUERY_PLAN[-1]
        payload = (
            '{"marker":"UPPER_BOUND_GUARD","id":999,"code":"<",'
            '"operands":["r->content_length","INT_MAX"],"file":"client.c",'
            '"line":395,"function":"client_parse_header"}'
        )
        result = QueryResult(
            spec.query_id,
            ExecutionStatus.SUCCESS,
            payload,
            "",
            0,
            1,
            backend="joern",
        )
        verdict, evidence = extract_t1(spec, result)
        self.assertIs(verdict, Verdict.REFUTED)
        self.assertEqual(evidence[0].node_id_origin, "joern")


if __name__ == "__main__":
    unittest.main()
