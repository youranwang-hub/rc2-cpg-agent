import json
import shutil
import unittest
import uuid
from pathlib import Path

from rc2_cpg_agent.executors import FixtureExecutor
from rc2_cpg_agent.models import HypothesisStatus
from rc2_cpg_agent.runner import AnalysisRunner


class DemoTest(unittest.TestCase):
    def setUp(self):
        self.output = Path.cwd() / ".test-tmp" / uuid.uuid4().hex
        self.output.mkdir(parents=True)

    def tearDown(self):
        shutil.rmtree(self.output, ignore_errors=True)

    def test_uhttpd_demo_tracks_real_findings_and_unknowns(self):
        import rc2_cpg_agent.runner as runner

        fixture_dir = Path(runner.__file__).parent / "fixtures" / "uhttpd"
        state = AnalysisRunner(FixtureExecutor(fixture_dir), self.output).run()

        self.assertIs(state.hypothesis.status, HypothesisStatus.LIKELY)
        self.assertEqual(len(state.hypothesis.verified_preconditions), 3)
        self.assertEqual(
            sorted(state.hypothesis.verified_preconditions),
            ["attacker_ctl_length", "chunk_to_int", "intra_dataflow_sink"],
        )
        self.assertEqual(
            sorted(state.hypothesis.verification_needed),
            ["cross_fn_dataflow_sink", "upper_bound_guard"],
        )
        self.assertAlmostEqual(state.hypothesis.verification_progress, 0.6)
        self.assertAlmostEqual(state.hypothesis.decision_progress, 0.6)
        self.assertEqual(state.termination_reason, "unresolved_conditions")

        final = json.loads((self.output / "final-state.json").read_text(encoding="utf-8"))
        self.assertEqual(final["termination_reason"], "unresolved_conditions")
        self.assertEqual(final["query_plan_version"], "uhttpd-real-run-v1")
        self.assertEqual(final["evidence"][0]["node_id_origin"], "fixture_placeholder")

        chain = final["evidence_chain"]
        self.assertEqual(len(chain), 3)
        self.assertTrue(
            any(
                item["query_id"] == "q3"
                and "client.c:473" in item["locations"]
                and "client_poll_post_data" in item["functions"]
                and item["code"]
                for item in chain
            )
        )


if __name__ == "__main__":
    unittest.main()
