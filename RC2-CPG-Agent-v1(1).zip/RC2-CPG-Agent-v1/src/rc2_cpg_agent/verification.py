from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import AnalysisState, ExecutionStatus
from .provenance import write_json

def verify_against_expected(
    state: AnalysisState,
    expected_path: Path,
    report_path: Path | None = None,
) -> dict[str, Any]:
    expected = json.loads(expected_path.read_text(encoding="utf-8"))
    checks: list[dict[str, Any]] = []
    results_by_query = {record.spec.query_id: record for record in state.query_history}

    for query_id, rule in expected["queries"].items():
        record = results_by_query.get(query_id)
        if record is None:
            checks.append(
                {
                    "query_id": query_id,
                    "check": "query_present",
                    "passed": False,
                    "detail": "查询没有执行",
                }
            )
            continue
        checks.append(
            {
                "query_id": query_id,
                "check": "execution_success",
                "passed": record.result.status is ExecutionStatus.SUCCESS,
                "detail": str(record.result.status),
            }
        )

        evidence = [item for item in state.evidence if item.query_id == query_id]
        if rule.get("must_be_empty"):
            checks.append(
                {
                    "query_id": query_id,
                    "check": "empty_result",
                    "passed": not evidence,
                    "detail": f"evidence_count={len(evidence)}",
                }
            )
            continue

        expected_locations = rule.get("locations", [])
        actual_locations = sorted({loc for item in evidence for loc in item.source_locations})
        if expected_locations:
            checks.append(
                {
                    "query_id": query_id,
                    "check": "locations",
                    "passed": actual_locations == sorted(expected_locations),
                    "expected": sorted(expected_locations),
                    "actual": actual_locations,
                }
            )

        expected_functions = rule.get("functions", [])
        actual_functions = sorted({fn for item in evidence for fn in item.functions if fn})
        if expected_functions:
            checks.append(
                {
                    "query_id": query_id,
                    "check": "functions",
                    "passed": actual_functions == sorted(expected_functions),
                    "expected": sorted(expected_functions),
                    "actual": actual_functions,
                }
            )

        code_contains = rule.get("code_contains")
        if code_contains:
            code_text = "\n".join(code for item in evidence for code in item.code)
            checks.append(
                {
                    "query_id": query_id,
                    "check": "code_contains",
                    "passed": code_contains in code_text,
                    "expected": code_contains,
                    "actual": code_text,
                }
            )

        expected_lines = rule.get("path_lines_unique", [])
        if expected_lines:
            actual_path_lines = sorted(
                {
                    int(node["line"])
                    for item in evidence
                    for node in item.path
                    if node.get("line") is not None
                }
            )
            checks.append(
                {
                    "query_id": query_id,
                    "check": "path_lines_unique",
                    "passed": actual_path_lines == sorted(expected_lines),
                    "expected": sorted(expected_lines),
                    "actual": actual_path_lines,
                }
            )

    passed = all(item["passed"] for item in checks)
    report = {
        "expected_file": str(expected_path.resolve()),
        "passed": passed,
        "checks": checks,
        "note": "本报告只比较实验报告中记录的源码锚点，不证明漏洞可被动态触发。",
    }
    if report_path is not None:
        write_json(report_path, report)
    return report
