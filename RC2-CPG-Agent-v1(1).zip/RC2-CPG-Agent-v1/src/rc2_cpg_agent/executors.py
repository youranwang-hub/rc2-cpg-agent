from __future__ import annotations

import hashlib
import json
import subprocess
import time
from pathlib import Path
from typing import Protocol

from .models import ExecutionStatus, QueryResult, QuerySpec


class QueryExecutor(Protocol):
    def execute(self, spec: QuerySpec) -> QueryResult: ...


class FixtureExecutor:
    """Replay versioned Joern-shaped JSON; no verdict is stored in fixtures."""

    def __init__(self, fixture_dir: Path) -> None:
        self.fixture_dir = fixture_dir

    def execute(self, spec: QuerySpec) -> QueryResult:
        started = time.perf_counter()
        path = self.fixture_dir / f"{spec.query_id}.jsonl"
        try:
            stdout = path.read_text(encoding="utf-8")
            status, stderr, code = ExecutionStatus.SUCCESS, "", 0
        except OSError as exc:
            stdout, stderr, code = "", str(exc), None
            status = ExecutionStatus.FAILED
        return QueryResult(
            spec.query_id,
            status,
            stdout,
            stderr,
            code,
            int((time.perf_counter() - started) * 1000),
            backend="fixture",
        )


class JoernExecutor:
    def __init__(self, joern: Path, cpg: Path, work_dir: Path, timeout_seconds: int = 60) -> None:
        self.joern, self.cpg, self.work_dir, self.timeout_seconds = joern, cpg, work_dir, timeout_seconds
        work_dir.mkdir(parents=True, exist_ok=True)

    def execute(self, spec: QuerySpec) -> QueryResult:
        script = self.work_dir / f"{spec.query_id}.sc"
        content = render_joern_script(spec, self.cpg)
        script.write_text(content, encoding="utf-8")
        script_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        command = (str(self.joern), "--script", str(script))
        started = time.perf_counter()
        try:
            process = subprocess.run(
                list(command),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout_seconds,
                check=False,
            )
            status = ExecutionStatus.SUCCESS if process.returncode == 0 else ExecutionStatus.FAILED
            return QueryResult(
                spec.query_id,
                status,
                process.stdout,
                process.stderr,
                process.returncode,
                int((time.perf_counter() - started) * 1000),
                backend="joern",
                command=command,
                script_path=str(script),
                script_sha256=script_hash,
            )
        except subprocess.TimeoutExpired as exc:
            return QueryResult(
                spec.query_id,
                ExecutionStatus.TIMEOUT,
                exc.stdout or "",
                exc.stderr or "",
                None,
                int((time.perf_counter() - started) * 1000),
                backend="joern",
                command=command,
                script_path=str(script),
                script_sha256=script_hash,
            )
        except OSError as exc:
            return QueryResult(
                spec.query_id,
                ExecutionStatus.FAILED,
                "",
                str(exc),
                None,
                int((time.perf_counter() - started) * 1000),
                backend="joern",
                command=command,
                script_path=str(script),
                script_sha256=script_hash,
            )


def render_joern_script(spec: QuerySpec, cpg_path: Path) -> str:
    """生成带 JSON 边界标记的 Joern 脚本。"""
    expression = spec.cpgql.strip()
    while expression.endswith(".toJsonPretty"):
        expression = expression[: -len(".toJsonPretty")].rstrip()
    cpg_literal = json.dumps(cpg_path.resolve().as_posix(), ensure_ascii=False)
    return (
        f"importCpg({cpg_literal})\n"
        "val __rc2_result = {\n"
        f"  {expression}.toJsonPretty\n"
        "}\n"
        'println("__RC2_JSON_BEGIN__")\n'
        "println(__rc2_result)\n"
        'println("__RC2_JSON_END__")\n'
    )


def detect_tool_version(command: str | Path, timeout_seconds: int = 20) -> str | None:
    """尝试读取 Joern 版本；失败不阻断正式实验。"""
    try:
        process = subprocess.run(
            [str(command), "--version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    output = "\n".join(part.strip() for part in (process.stdout, process.stderr) if part.strip())
    return output or None


def save_raw_result(result: QueryResult, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / f"{result.query_id}.stdout.txt").write_text(result.stdout, encoding="utf-8")
    (directory / f"{result.query_id}.stderr.txt").write_text(result.stderr, encoding="utf-8")
    metadata = {
        "status": result.status,
        "return_code": result.return_code,
        "duration_ms": result.duration_ms,
        "backend": result.backend,
        "command": list(result.command),
        "script_path": result.script_path,
        "script_sha256": result.script_sha256,
    }
    (directory / f"{result.query_id}.meta.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

