from .models import Preconditions, QuerySpec, Verdict, VulnerabilityHypothesis


QUERY_PLAN_VERSION = "uhttpd-real-run-v1"


# CVE-2019-19945 (uhttpd HTTP POST 长度解析) —— 前置条件集合。
# 依据 experiments/uhttpd（uhttpd/client.c 与 uhttpd.cpg.bin，commit 接近 778ccbb）的真实 Joern 结果转录。
# 真实可判定事实(报告已核验)与诚实限制(跨函数 / 类型 / 上界守卫)被建模为不同条件：
#   VERIFIED  : 源码节点可被 Joern 定位（attacker_ctl_length / chunk_to_int / intra_dataflow_sink）
#   UNKNOWN   : 当前静态查询无法闭合（cross_fn_dataflow_sink / upper_bound_guard），不当作 REFUTED
UHTTPD_PRECONDITIONS = (
    Preconditions("attacker_ctl_length", "攻击者可控的 Content-Length 头被解析进 request（client_parse_header 内 r->content_length 赋值）"),
    Preconditions("chunk_to_int", "chunk-size 经 strtoul(buf,..,16) 解析并赋值给 int content_length（client_poll_post_data）"),
    Preconditions("intra_dataflow_sink", "同一函数内 content_length 经 min() 到达 ustream_consume sink"),
    Preconditions("cross_fn_dataflow_sink", "跨函数(client_parse_header -> client_poll_post_data)字段流到达 ustream_consume"),
    Preconditions("upper_bound_guard", "缺少 INT_MAX 上界检查(仅 <0 守卫), 使 strtoul 截断值可绕过守卫"),
)


# 固定查询计划：每条查询只绑定一个前置条件。
# 这里只保存查询表达式，不包含 .toJsonPretty；执行器统一负责 JSON 包装。
# 候选查询必须先在实验室用 Joern 4.0.550 验证，不能把尚未执行的查询说成已跑通。
UHTTPD_QUERY_PLAN = (
    QuerySpec(
        "q1", "attacker_ctl_length",
        "在 client_parse_header 中定位 Content-Length 的 strtoul 赋值",
        'cpg.method.name("client_parse_header").ast.assignment.where(_.target.code(".*content_length.*")).where(_.source.isCall.name("strtoul")).map(n => Map("marker" -> "INPUT", "id" -> n.id, "code" -> n.code, "file" -> n.file.name.headOption, "line" -> n.lineNumber, "function" -> n.method.name))',
        "INPUT",
    ),
    QuerySpec(
        "q2", "chunk_to_int",
        "定位 chunk-size 的 strtoul 解析赋值点 client_poll_post_data:489",
        'cpg.method.name("client_poll_post_data").ast.assignment.where(_.target.code(".*content_length.*")).where(_.source.isCall.name("strtoul")).map(n => Map("marker" -> "CONVERSION", "id" -> n.id, "code" -> n.code, "file" -> n.file.name.headOption, "line" -> n.lineNumber, "function" -> n.method.name))',
        "CONVERSION",
    ),
    QuerySpec(
        "q3", "intra_dataflow_sink",
        "同函数内 strtoul(content_length) 污点流到达 ustream_consume(cl->us, cur_len)",
        'val src = cpg.method.name("client_poll_post_data").ast.isCall.name("strtoul"); val sink = cpg.method.name("client_poll_post_data").ast.isCall.name("ustream_consume"); sink.reachableByFlows(src).map(p => Map("marker" -> "DATAFLOW", "path" -> p.elements.map(n => Map("id" -> n.id, "code" -> n.code, "file" -> n.file.name.headOption, "line" -> n.lineNumber, "function" -> n.method.name)).l))',
        "DATAFLOW",
    ),
    QuerySpec(
        "q4", "cross_fn_dataflow_sink",
        "跨函数字段流: client_parse_header 的 strtoul 到达 client_poll_post_data 的 ustream_consume",
        'val src = cpg.method.name("client_parse_header").ast.isCall.name("strtoul"); val sink = cpg.method.name("client_poll_post_data").ast.isCall.name("ustream_consume"); sink.reachableByFlows(src).map(p => Map("marker" -> "DATAFLOW", "path" -> p.elements.map(n => Map("id" -> n.id, "code" -> n.code, "file" -> n.file.name.headOption, "line" -> n.lineNumber, "function" -> n.method.name)).l))',
        "DATAFLOW",
    ),
    QuerySpec(
        "q5", "upper_bound_guard",
        "在 client_parse_header 中查找 INT_MAX 上界守卫；找到守卫会反驳“守卫缺失”条件，空结果仍为 UNKNOWN",
        'cpg.method.name("client_parse_header").ast.isCall.name("<operator>.lessThan").where(_.argument.code(".*content_length.*")).where(_.argument.code("INT_MAX|2147483647")).map(n => Map("marker" -> "UPPER_BOUND_GUARD", "id" -> n.id, "code" -> n.code, "operands" -> n.argument.code.l, "file" -> n.file.name.headOption, "line" -> n.lineNumber, "function" -> n.method.name))',
        "UPPER_BOUND_GUARD",
        Verdict.REFUTED,
    ),
)


def build_uhttpd_hypothesis() -> VulnerabilityHypothesis:
    conditions = {item.condition_id: item for item in UHTTPD_PRECONDITIONS}
    return VulnerabilityHypothesis(
        hypothesis_id="CVE-2019-19945-uhttpd",
        title="uhttpd attacker-controlled length reaches ustream_consume via int truncation",
        preconditions=conditions,
        verification_needed=list(conditions),
    )
