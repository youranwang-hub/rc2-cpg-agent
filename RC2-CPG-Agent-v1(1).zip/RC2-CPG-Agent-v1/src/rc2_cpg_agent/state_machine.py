from .models import AnalysisState, HypothesisStatus, Verdict


def apply_verdict(state: AnalysisState, condition_id: str, verdict: Verdict) -> None:
    """确定性状态迁移：只有已核验或已证伪的条件才离开 verification_needed。

    UNKNOWN 不迁移条件（保持 unresolved），因为它不代表证伪。
    """
    hypothesis = state.hypothesis
    if condition_id not in hypothesis.verification_needed:
        # 已决定或未知的条件被重复裁定 => 内部错误，防止循环改写状态。
        raise ValueError(f"condition already decided or unknown: {condition_id}")
    if verdict is Verdict.VERIFIED:
        hypothesis.verified_preconditions.append(condition_id)
        hypothesis.verification_needed.remove(condition_id)
    elif verdict is Verdict.REFUTED:
        hypothesis.refuted_preconditions.append(condition_id)
        hypothesis.verification_needed.remove(condition_id)
    # UNKNOWN：不迁移，条件保留在 verification_needed，代表本轮未能闭合。
    _recompute(hypothesis)


def _recompute(hypothesis) -> None:
    total = len(hypothesis.preconditions)
    verified = len(hypothesis.verified_preconditions)
    refuted = len(hypothesis.refuted_preconditions)
    hypothesis.verification_progress = verified / total if total else 0.0
    hypothesis.decision_progress = (verified + refuted) / total if total else 0.0
    if hypothesis.refuted_preconditions:
        hypothesis.status = HypothesisStatus.REFUTED
    elif verified == total:
        hypothesis.status = HypothesisStatus.CONFIRMED
    elif verified:
        hypothesis.status = HypothesisStatus.LIKELY
    else:
        hypothesis.status = HypothesisStatus.SPECULATIVE


def validate_state(state) -> None:
    """检查同一条件不会同时进入 verified、refuted 和 pending。"""
    hypothesis = state.hypothesis
    verified = set(hypothesis.verified_preconditions)
    refuted = set(hypothesis.refuted_preconditions)
    pending = set(hypothesis.verification_needed)
    known = set(hypothesis.preconditions)
    if verified & refuted:
        raise ValueError(f"condition both verified and refuted: {sorted(verified & refuted)}")
    if (verified | refuted | pending) - known:
        raise ValueError("state contains unknown condition ids")
    if (verified & pending) or (refuted & pending):
        raise ValueError("a decided condition cannot remain pending")


def should_stop(state: AnalysisState) -> bool:
    """终止判定（确定性）。

    返回 True 表示应停止，并设置 termination_reason：
    - confirmed  / refuted：全部条件有确定性结论
    - unresolved_conditions：还有条件停留在 unknown（成功但空 / 无封闭世界）
    - max_iterations：达到查询轮次上限
    """
    if state.hypothesis.status is HypothesisStatus.CONFIRMED:
        state.termination_reason = "confirmed"
        return True
    if state.hypothesis.status is HypothesisStatus.REFUTED:
        state.termination_reason = "refuted"
        return True
    if state.iteration >= state.max_iterations:
        state.termination_reason = "max_iterations"
        return True
    return False
