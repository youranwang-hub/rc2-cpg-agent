from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

from .cases import UHTTPD_QUERY_PLAN
from .executors import FixtureExecutor, JoernExecutor, detect_tool_version, render_joern_script
from .provenance import PROJECT_VERSION, build_manifest, utc_now, write_json
from .runner import AnalysisRunner
from .verification import verify_against_expected


PROJECT_ROOT = Path(__file__).resolve().parents[2]
EXPECTED_ANCHORS = PROJECT_ROOT / "expected_anchors.json"
DEFAULT_SOURCE_ROOT = PROJECT_ROOT / "reference" / "uhttpd-case" / "uhttpd"
REFERENCE_REPORT = PROJECT_ROOT / "reference" / "uhttpd-case" / "experiment_report.md"
KNOWN_SOURCE_COMMIT = "778ccbbf5f8aa90e368100897f59322314287ab4"


def _resolve_joern(value: str) -> Path:
    candidate = Path(value).expanduser()
    if candidate.exists():
        return candidate.resolve()
    found = shutil.which(value)
    return Path(found).resolve() if found else candidate


def _prepare_run_dir(base: Path) -> Path:
    base.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    run_dir = base / f"run-{stamp}"
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


def _print_summary(state, run_dir: Path, anchor_report: dict | None = None) -> None:
    hypothesis = state.hypothesis
    print("\n实验完成")
    print(f"  状态: {hypothesis.status}")
    print(f"  已确认条件: {len(hypothesis.verified_preconditions)}/{len(hypothesis.preconditions)}")
    print(f"  已反驳条件: {len(hypothesis.refuted_preconditions)}/{len(hypothesis.preconditions)}")
    print(f"  尚未闭合: {', '.join(hypothesis.verification_needed) or '无'}")
    print(f"  终止原因: {state.termination_reason}")
    print(f"  结果目录: {run_dir}")
    if anchor_report is not None:
        print(f"  与实验报告锚点一致: {'是' if anchor_report['passed'] else '否'}")


def _write_manifest(
    *,
    run_dir: Path,
    state,
    backend: str,
    started_at: str,
    cpg_path: Path | None,
    source_root: Path | None,
    joern_path: Path | None,
    joern_version: str | None,
) -> Path:
    manifest = build_manifest(
        output_dir=run_dir,
        state=state,
        backend=backend,
        started_at=started_at,
        cpg_path=cpg_path,
        source_root=source_root,
        joern_path=joern_path,
        joern_version=joern_version,
        known_source_commit=KNOWN_SOURCE_COMMIT,
        expected_anchor_path=EXPECTED_ANCHORS,
        reference_report_path=REFERENCE_REPORT,
    )
    path = run_dir / "manifest.json"
    write_json(path, manifest)
    return path


def command_local(args: argparse.Namespace) -> int:
    started_at = utc_now()
    run_dir = _prepare_run_dir(args.output_dir)
    fixture_dir = Path(__file__).parent / "fixtures" / "uhttpd"
    state = AnalysisRunner(FixtureExecutor(fixture_dir), run_dir).run(args.max_iterations)
    _write_manifest(
        run_dir=run_dir,
        state=state,
        backend="fixture",
        started_at=started_at,
        cpg_path=None,
        source_root=DEFAULT_SOURCE_ROOT,
        joern_path=None,
        joern_version=None,
    )
    anchor_report = None
    if args.verify_expected:
        anchor_report = verify_against_expected(
            state,
            EXPECTED_ANCHORS,
            run_dir / "anchor-check.json",
        )
    _print_summary(state, run_dir, anchor_report)
    if args.fail_on_anchor_mismatch and anchor_report and not anchor_report["passed"]:
        return 3
    return 0


def command_lab(args: argparse.Namespace) -> int:
    joern = _resolve_joern(args.joern)
    cpg = args.cpg.expanduser().resolve()
    source_root = args.source_root.expanduser().resolve() if args.source_root else DEFAULT_SOURCE_ROOT.resolve()
    if not joern.exists():
        print(f"错误: 找不到 Joern: {joern}", file=sys.stderr)
        return 2
    if not cpg.is_file():
        print(f"错误: 找不到 CPG 文件: {cpg}", file=sys.stderr)
        return 2

    run_dir = _prepare_run_dir(args.output_dir)
    if args.dry_run:
        scripts_dir = run_dir / "scripts"
        scripts_dir.mkdir()
        script_rows = []
        for spec in UHTTPD_QUERY_PLAN:
            path = scripts_dir / f"{spec.query_id}.sc"
            path.write_text(render_joern_script(spec, cpg), encoding="utf-8")
            script_rows.append({"query_id": spec.query_id, "script": str(path)})
        write_json(
            run_dir / "dry-run.json",
            {
                "message": "仅生成脚本，没有执行 Joern",
                "joern": str(joern),
                "cpg": str(cpg),
                "scripts": script_rows,
            },
        )
        print(f"已生成查询脚本，未执行 Joern。目录: {run_dir}")
        return 0

    started_at = utc_now()
    joern_version = args.joern_version or detect_tool_version(joern)
    executor = JoernExecutor(joern, cpg, run_dir / "scripts", timeout_seconds=args.timeout)
    state = AnalysisRunner(executor, run_dir).run(args.max_iterations)
    _write_manifest(
        run_dir=run_dir,
        state=state,
        backend="joern",
        started_at=started_at,
        cpg_path=cpg,
        source_root=source_root,
        joern_path=joern,
        joern_version=joern_version,
    )
    anchor_report = None
    if args.verify_expected:
        anchor_report = verify_against_expected(
            state,
            EXPECTED_ANCHORS,
            run_dir / "anchor-check.json",
        )
    _print_summary(state, run_dir, anchor_report)

    failed = [
        record.spec.query_id
        for record in state.query_history
        if record.result.status.value != "success"
    ]
    if failed:
        print(f"错误: 以下查询执行失败: {', '.join(failed)}", file=sys.stderr)
        return 2
    if args.fail_on_anchor_mismatch and anchor_report and not anchor_report["passed"]:
        return 3
    return 0


def command_preflight(args: argparse.Namespace) -> int:
    joern = _resolve_joern(args.joern)
    cpg = args.cpg.expanduser().resolve()
    source_root = args.source_root.expanduser().resolve() if args.source_root else DEFAULT_SOURCE_ROOT.resolve()
    checks = [
        {"name": "Joern 可执行文件", "passed": joern.exists(), "value": str(joern)},
        {"name": "CPG 文件", "passed": cpg.is_file() and cpg.stat().st_size > 0, "value": str(cpg)},
        {
            "name": "源码 client.c",
            "passed": (source_root / "client.c").is_file(),
            "value": str(source_root / "client.c"),
        },
        {"name": "预期锚点文件", "passed": EXPECTED_ANCHORS.is_file(), "value": str(EXPECTED_ANCHORS)},
    ]
    version = detect_tool_version(joern) if joern.exists() else None
    checks.append({"name": "Joern 版本可读取", "passed": bool(version), "value": version})
    passed = all(item["passed"] for item in checks)
    payload = {
        "passed": passed,
        "project_version": PROJECT_VERSION,
        "checked_at": utc_now(),
        "checks": checks,
    }
    if args.report:
        write_json(args.report.expanduser().resolve(), payload)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if passed else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RC2 uhttpd CPG 分析 Demo：本地回放与实验室真实 Joern 运行"
    )
    parser.add_argument("--version", action="version", version=PROJECT_VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)

    local = subparsers.add_parser("local", help="使用冻结 fixture 在本机运行")
    local.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "artifacts" / "local-run")
    local.add_argument("--max-iterations", type=int, default=10)
    local.add_argument("--verify-expected", action=argparse.BooleanOptionalAction, default=True)
    local.add_argument("--fail-on-anchor-mismatch", action="store_true")
    local.set_defaults(func=command_local)

    lab = subparsers.add_parser("lab", help="使用真实 Joern 和 CPG 运行")
    lab.add_argument("--joern", required=True, help="joern 可执行文件或命令名")
    lab.add_argument("--cpg", type=Path, required=True, help="uhttpd.cpg.bin 路径")
    lab.add_argument("--source-root", type=Path, help="uhttpd 源码目录")
    lab.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "artifacts" / "lab-run")
    lab.add_argument("--timeout", type=int, default=180)
    lab.add_argument("--max-iterations", type=int, default=10)
    lab.add_argument("--joern-version", help="已知版本；不填则尝试自动读取")
    lab.add_argument("--dry-run", action="store_true", help="只生成脚本，不执行 Joern")
    lab.add_argument("--verify-expected", action=argparse.BooleanOptionalAction, default=True)
    lab.add_argument("--fail-on-anchor-mismatch", action="store_true")
    lab.set_defaults(func=command_lab)

    preflight = subparsers.add_parser("preflight", help="实验室运行前检查路径和版本")
    preflight.add_argument("--joern", required=True)
    preflight.add_argument("--cpg", type=Path, required=True)
    preflight.add_argument("--source-root", type=Path)
    preflight.add_argument("--report", type=Path)
    preflight.set_defaults(func=command_preflight)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)
