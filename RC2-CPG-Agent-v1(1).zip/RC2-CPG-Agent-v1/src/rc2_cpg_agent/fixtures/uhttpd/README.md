# uhttpd fixtures —— 真实 Joern 结果的转录契约

这些 `.jsonl` 是从真实 Joern 实验转录的、在无 Joern 环境下可重复回放的冻结输入；
每条都对应 `cases.py::UHTTPD_QUERY_PLAN` 中一条查询（通过文件 q<id>.jsonl 与 query_id 关联），
并且证据通过 `(file, line, function, code)` 绑定到真实源码片段。

## 来源（真实可核验事实）

- 目标：OpenWRT uhttpd，commit 接近 `778ccbb`（CVE-2019-19945 修复前）。
- 源码/CPG：`uhttpd案例/uhttpd/client.c` 与 `uhttpd.cpg.bin`。
- 记录：`experiment_report.md`（Joern 4.0.550，c2cpg）。
- 已验证源码锚点（与报告一致）：
  - `client.c:394` `client_parse_header`   `r->content_length = strtoul(val, &err, 10)`
  - `client.c:489` `client_poll_post_data` `r->content_length = strtoul(buf + offset, &sep, 16)`
  - `client.c:464` `cur_len = min(r->content_length, len)`
  - `client.c:473` `ustream_consume(cl->us, cur_len)`  ← sink
  - 函数内路径：`489 → 489 → 464 → 473`（报告已验证，9 步路径的代表节点）
  - `client_parse_header:394` 的字段流到 `client_poll_post_data:473` **未找到**

## 逐文件语义

| 文件 | condition_id | marker | 真实结果 | 转录 |
|---|---|---|---|---|
| q1.jsonl | attacker_ctl_length | INPUT | 头解析赋值命中 | 1 条（394）→ VERIFIED |
| q2.jsonl | chunk_to_int | CONVERSION | chunk-size strtoul 命中 | 1 条（489）→ VERIFIED |
| q3.jsonl | intra_dataflow_sink | DATAFLOW | 函数内污点流命中 | 1 条 path（489→464→473）→ VERIFIED |
| q4.jsonl | cross_fn_dataflow_sink | DATAFLOW | 跨函数字段流**未找到** | 空 → UNKNOWN |
| q5.jsonl | upper_bound_guard | UPPER_BOUND_GUARD | 未找到 `INT_MAX` 上界守卫；源码中的 `< 0` 守卫不是上界守卫 | 空 → UNKNOWN |

q4 / q5 为真实 Joern 下"无命中"的结果转录，因此文件为空；`extract_t1` 对成功但空的结果返回
`UNKNOWN`（未闭合），状态机据此把 `cross_fn_dataflow_sink`、`upper_bound_guard` 保留为待验证，
最终状态为 `LIKELY` + `unresolved_conditions`，而**不是**把所有条件都推成 `CONFIRMED`。

`q5` 的判定方向与前三项不同：查询标记为 `UPPER_BOUND_GUARD`，如果找到守卫，说明
“守卫缺失”条件被反驳；如果没找到，因为没有封闭世界保证，仍只能是 `UNKNOWN`。

## 诚实限制（id 不是真实 CPG id）

- `id` 字段是**稳定的占位整数**：真实 CPG 节点 id 需在本机 Joern 上对 `uhttpd.cpg.bin`
  重新执行 `query1_basic.sc` / `query2_taint.sc`（或 `cases.py` 中的 CPGQL）后才可获得。
  因此请以 `file:line:function:code` 作为证据身份与可追溯依据，`id` 仅用于 demo 内自洽。
- 报告第 3 步指出：粗查询返回空的"缺少检查"结论不可信（源码存在 `< 0` 守卫），
  故 q5 空结果只记为 UNKNOWN，**不**作为"缺少上界检查"的证实或证伪。

## 如何替换为真实输出

在有 Joern 的机器上，把 `cases.py` 的每条 CPGQL 写成 `.sc`，由执行器统一添加一次 `toJsonPretty`，
将各查询 stdout 逐行写入对应 `q<id>.jsonl` 即可替换本目录；命中数或 path 节点数变化时，
状态机会自动得到新的 VERIFIED/UNKNOWN 组合。
