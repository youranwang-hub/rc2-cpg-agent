from __future__ import annotations

import json
import posixpath

from .models import Evidence, ExecutionStatus, QueryResult, QuerySpec, Verdict


def _fmt_location(node: dict) -> str:
    """file:line，供人工回到源码片段。file 取 basename 以免被 CPG 全路径污染。"""
    raw = str(node.get("file", "?"))
    base = posixpath.basename(raw.replace("\\", "/"))
    return f"{base}:{node.get('line', '?')}"


def _record_nodes(record: dict) -> list[dict]:
    """返回用于构成 T1 证据的节点序列。

    数据流型记录携带 path（元素为节点）；标量型记录本身即节点。
    """
    path = record.get("path")
    if path:
        return [n for n in path if isinstance(n, dict)]
    return [record]


JSON_BEGIN = "__RC2_JSON_BEGIN__"
JSON_END = "__RC2_JSON_END__"


def extract_json_records(stdout: str) -> list[dict]:
    """兼容 Joern 的 JSON 数组、单对象和冻结 fixture 的 JSONL。"""
    text = stdout.strip()
    if JSON_BEGIN in text and JSON_END in text:
        start = text.index(JSON_BEGIN) + len(JSON_BEGIN)
        end = text.rindex(JSON_END)
        text = text[start:end].strip()
    if not text:
        return []

    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        payload = None
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        return [payload]

    records: list[dict] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or not stripped.startswith(("{", "[")):
            continue
        try:
            item = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict):
            records.append(item)
        elif isinstance(item, list):
            records.extend(part for part in item if isinstance(part, dict))
    return records


def extract_t1(
    spec: QuerySpec,
    result: QueryResult,
    *,
    node_id_origin: str | None = None,
) -> tuple[Verdict, list[Evidence]]:
    """从 Joern stdout 解析 JSON，提取 positive_marker 匹配的 T1 证据。

    信任边界（阶段一约束）：
    - 只有 status == SUCCESS 且能够解析出 JSON 记录时才可能产出 T1。
    - 成功但零命中（无 positive_marker 记录）=> UNKNOWN 而非 REFUTED，
      因为没有封闭世界保证；调用方不得据此判定条件不存在。
    """
    if result.status is not ExecutionStatus.SUCCESS:
        return Verdict.UNKNOWN, []
    if not isinstance(result.stdout, str):
        return Verdict.UNKNOWN, []
    records = extract_json_records(result.stdout)
    matched = [item for item in records if item.get("marker") == spec.positive_marker]
    if not matched:
        return Verdict.UNKNOWN, []

    evidence: list[Evidence] = []
    for index, record in enumerate(matched, 1):
        nodes = _record_nodes(record)
        seen: set[int] = set()
        ids: list[int] = []
        locs: list[str] = []
        codes: list[str] = []
        funcs: list[str] = []
        for node in nodes:
            raw_id = node.get("id")
            if raw_id is None:
                continue
            node_id = int(raw_id)
            if node_id in seen:  # 同一证据内节点去重
                continue
            seen.add(node_id)
            ids.append(node_id)
            locs.append(_fmt_location(node))
            codes.append(str(node.get("code", "")))
            funcs.append(str(node.get("function", "")) or "")
        if not ids:
            continue
        origin = node_id_origin or result.backend
        if origin == "fixture":
            origin = "fixture_placeholder"
        evidence.append(Evidence(
            evidence_id=f"{spec.query_id}-t1-{index}",
            tier="T1",
            query_id=spec.query_id,
            condition_id=spec.condition_id,
            cpg_node_ids=tuple(ids),
            source_locations=tuple(locs),
            code=tuple(codes),
            functions=tuple(funcs),
            path=tuple(nodes),
            node_id_origin=origin,
        ))
    if not evidence:
        return Verdict.UNKNOWN, []
    return spec.marker_verdict, evidence
