from __future__ import annotations

import hashlib
import json
import platform
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any

from .cases import UHTTPD_QUERY_PLAN
from .models import AnalysisState


PROJECT_VERSION = "0.2.0"


def utc_now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def detect_git_commit(source_root: Path | None) -> str | None:
    if source_root is None:
        return None
    try:
        process = subprocess.run(
            ["git", "-C", str(source_root), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    value = process.stdout.strip()
    return value if process.returncode == 0 and value else None


def build_manifest(
    *,
    output_dir: Path,
    state: AnalysisState,
    backend: str,
    started_at: str,
    cpg_path: Path | None,
    source_root: Path | None,
    joern_path: str | Path | None,
    joern_version: str | None,
    known_source_commit: str | None,
    expected_anchor_path: Path | None = None,
    reference_report_path: Path | None = None,
) -> dict[str, Any]:
    query_rows = []
    for record in state.query_history:
        script_path = Path(record.result.script_path) if record.result.script_path else None
        query_rows.append(
            {
                "query_id": record.spec.query_id,
                "condition_id": record.spec.condition_id,
                "purpose": record.spec.purpose,
                "cpgql": record.spec.cpgql,
                "positive_marker": record.spec.positive_marker,
                "marker_verdict": record.spec.marker_verdict,
                "execution_status": record.result.status,
                "return_code": record.result.return_code,
                "duration_ms": record.result.duration_ms,
                "verdict": record.verdict,
                "evidence_count": len(record.evidence_ids),
                "command": list(record.result.command),
                "script_path": str(script_path) if script_path else None,
                "script_sha256": record.result.script_sha256,
            }
        )

    client_source = source_root / "client.c" if source_root else None
    raw_files = {
        path.name: sha256_file(path)
        for path in sorted((output_dir / "raw").glob("*"))
        if path.is_file()
    }
    final_state = output_dir / "final-state.json"
    iterations = output_dir / "iterations.jsonl"
    manifest = {
        "schema_version": "1.0",
        "project": "rc2-cpg-agent",
        "project_version": PROJECT_VERSION,
        "run_finished_at": utc_now(),
        "run_started_at": started_at,
        "backend": backend,
        "case_id": state.case_id,
        "query_plan_version": state.query_plan_version,
        "hypothesis_status": state.hypothesis.status,
        "verification_progress": state.hypothesis.verification_progress,
        "decision_progress": state.hypothesis.decision_progress,
        "termination_reason": state.termination_reason,
        "tool": {
            "joern_path": str(joern_path) if joern_path else None,
            "joern_version": joern_version,
            "python_version": platform.python_version(),
        },
        "inputs": {
            "cpg_path": str(cpg_path.resolve()) if cpg_path else None,
            "cpg_sha256": sha256_file(cpg_path) if cpg_path and cpg_path.is_file() else None,
            "source_root": str(source_root.resolve()) if source_root else None,
            "source_client_c": str(client_source.resolve()) if client_source and client_source.is_file() else None,
            "source_client_sha256": sha256_file(client_source) if client_source and client_source.is_file() else None,
            "detected_source_commit": detect_git_commit(source_root),
            "known_source_commit": known_source_commit,
            "expected_anchor_path": str(expected_anchor_path.resolve()) if expected_anchor_path else None,
            "expected_anchor_sha256": sha256_file(expected_anchor_path) if expected_anchor_path and expected_anchor_path.is_file() else None,
            "reference_report_path": str(reference_report_path.resolve()) if reference_report_path else None,
            "reference_report_sha256": sha256_file(reference_report_path) if reference_report_path and reference_report_path.is_file() else None,
        },
        "queries": query_rows,
        "outputs": {
            "final_state": str(final_state.resolve()),
            "final_state_sha256": sha256_file(final_state) if final_state.is_file() else None,
            "iterations": str(iterations.resolve()),
            "iterations_sha256": sha256_file(iterations) if iterations.is_file() else None,
            "raw_directory": str((output_dir / "raw").resolve()),
            "raw_file_sha256": raw_files,
        },
        "limitations": [
            "fixture 模式的节点 ID 是冻结占位值，不能当作真实 CPG ID。",
            "空查询结果不等于条件为假；没有封闭世界保证时状态保持 unknown。",
            "当前脚本仍需在 Joern 4.0.550 和相同 CPG 上实测后，才能声明真实运行成功。",
        ],
    }
    return manifest


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def planned_query_rows() -> list[dict[str, Any]]:
    return [
        {
            "query_id": spec.query_id,
            "condition_id": spec.condition_id,
            "positive_marker": spec.positive_marker,
            "marker_verdict": spec.marker_verdict,
        }
        for spec in UHTTPD_QUERY_PLAN
    ]
